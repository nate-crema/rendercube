<template>
    <dashboard></dashboard>
</template>

<script>

import dashboard from '~/pages/workarea/dashboard.vue';

export default {
    components: {
        dashboard
    }
}
</script>

<style>

</style>

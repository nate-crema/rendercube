import Vue from 'vue';
import ww_plugin from '~/plugins/ww_plugin.js'

export default () => {
    Vue.use(ww_plugin)
}
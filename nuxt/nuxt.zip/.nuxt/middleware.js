const middleware = {}

middleware['auth'] = require('../middleware/auth.js');
middleware['auth'] = middleware['auth'].default || middleware['auth']

middleware['session'] = require('../middleware/session.js');
middleware['session'] = middleware['session'].default || middleware['session']

export default middleware

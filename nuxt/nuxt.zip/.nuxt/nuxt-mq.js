import Vue from 'vue'
import VueMq from 'vue-mq'

export default async function () {
  const moduleOptions = {}
  Vue.use(VueMq, moduleOptions)
}

<template>
    <div class="ram_usage modules_sys module">
        <div class="title_cover">
            <p class="title">RAM 사용량</p>
        </div>
        <div class="circle_graph_ram">
            
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.ram_usage {
    top: -220px;
    left: 250px;
}
.ram_usage .title_cover {

}
</style>

<template>
    <div class="cpu_usage modules_sys module">
        <div class="title_cover">
            <p class="title">CPU 사용량</p>
        </div>
        <div class="circle_graph_cpu">
            
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.cpu_usage {
    top: 20px;
}
.cpu_usage .title_cover {

}
</style>

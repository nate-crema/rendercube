<template>
    <div class="ftp_usage modules_sys module">
        <div class="title_cover">
            <p class="title">FTP 사용량</p>
        </div>
        <div class="circle_graph_ftp">
            
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.ftp_usage {
    top: -440px;
    left: 250px;
}
.ftp_usage .title_cover {

}
</style>

<template>
    <div class="gpu_usage modules_sys module">
        <div class="title_cover">
            <p class="title">GPU 사용량</p>
        </div>
        <div class="circle_graph_gpu">
            
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.gpu_usage {
    top: -200px;
}
.gpu_usage .title_cover {

}
</style>

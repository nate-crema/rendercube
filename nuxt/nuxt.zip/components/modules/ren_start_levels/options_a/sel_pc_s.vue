<template>
    <div class="select_area sel_pc_s boxes">
        <router-link to="">
            <div class="img">
                <img src="~/assets/img/pc_s.svg" class="img_explain"/>
            </div>
            <p class="type">공유PC에서 처리하기</p>
            <p class="explain_type">타인의 PC에서 렌더링을 합니다.<br>사전에 Rendercube 원격 렌더링 프로그램에 <br>공개상태로 등록된 PC에서 렌더링합니다.</p>
        </router-link>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.sel_pc_s {    
    position: relative;
    top: -720px;
    left: 750px;
}
</style>

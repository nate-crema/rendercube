<template>
    <div class="sel_load_file module select_area">
        <div class="img">
            <img src="">
        </div>
        <p class="type">업로드된 프로젝트 선택</p>
        <p class="explain_type">기존에 업로드된 파일이나<br>타사 드라이브에서 프로젝트를 불러옵니다.</p>
    </div>
</template>

<script>
export default {

}
</script>

<style>
.sel_load_file {
    width: 300px;
    height: 400px;
    position: relative;
    top: -400px;
    left: 600px;
}
</style>
